#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>

pthread_mutex_t turn;
pthread_mutex_t mutex; // mutex declaration
pthread_barrier_t barrier; //barrier declaration
int officeCapacity; //the number of students allow in the office at a time
int numberStudents; //the number of students that want to ask questions
int studentTurn;
int maxCapacity;
int studentsDone;

//The professor starts to answer a question of a student.
void AnswerStart(int studentID){
  printf("Professor starts to answer question for student %d.\n", studentID);
}

//The professor is done answering a question of a student.
void AnswerDone(int studentID){
  printf("Professor is done with answer for student %d.\n", studentID);
}

//It is the student’s turn to enter the professor’s office to ask questions.
void EnterOffice(int studentID){
  printf("Student %d enters the office.\n", studentID);
}

//The student has no more questions to ask, so he/she leaves the professor’s office.
void LeaveOffice(int studentID){
  printf("Student %d leaves the office.\n", studentID);
}

//It is the turn of the student to ask his/her next question.
void QuestionStart(int studentID){
  printf("Student %d asks a question.\n", studentID);
}

//The student is satisfied with the answer to his most recent question.
void QuestionDone(int studentID){
  printf("Student %d is satisfied.\n", studentID);
}



//This functions starts a thread that runs a loop calling AnswerStart() and AnswerDone().AnswerStart() blocks when there are no students around.
void* Professor(){
 while (studentsDone){  
   if (studentTurn){
     pthread_mutex_lock(&turn);
     AnswerStart(studentTurn);
     AnswerDone(studentTurn);
     studentTurn=0;
     pthread_mutex_unlock(&turn);
   }
 }
}

/*
This function creates a thread that represents a new student with identifier id that asks
the professor one or more questions (the identifier given to your function can be expected to be
greater or equal to zero and the first student's id is zero). First, each student needs to enter the
professor’s office by calling EnterOffice(). If the office is already full, the student must wait. After a
student enters the office, he/she loops running the code QuestionStart() and QuestionDone() for the
number of questions that he/she wants to ask. The number of questions is determined by calculating
(student identifier modulo 4 plus 1). That is, each student can ask between 1 and 4 questions,
depending on the id. For example, a student with id 2 asks 3 questions, a student with id 11 asks 4
questions and a student with id 4 asks a single question. Once the student has got the answer for all
his/her questions, he/she must call LeaveOffice(). As a result, another student waiting on EnterOffice()
may be able to proceed. 
*/
void* Student(int id){
 int inOffice = 0; 
 int numOfQuestions = (id % 4) + 1;
 //printf("Student %d can ask %d questions.\n", id, numOfQuestions);
 //printf("The office capacity is %d.\n", officeCapacity);
 while(!inOffice){

   pthread_mutex_lock(&mutex);
   if (officeCapacity > 0){
     EnterOffice(id);
     officeCapacity--;     
     inOffice = 1;
   }
   pthread_mutex_unlock(&mutex);
 }
 if (random() > RAND_MAX / 2)
 usleep(500);
 while(numOfQuestions){
   pthread_mutex_lock(&mutex);
   QuestionStart(id);
   pthread_mutex_lock(&turn);
   studentTurn = id;
   pthread_mutex_unlock(&turn);
   while(studentTurn);
   QuestionDone(id);
   pthread_mutex_unlock(&mutex);
   numOfQuestions--;
 }
 //sleep(200);
 LeaveOffice(id);
 //pthread_mutex_lock(&mutex);
 officeCapacity++;
 //pthread_mutex_unlock(&mutex);
 
} 


int validateArguments(char* argv){
  //check that the argument is a number 
  while(*argv != '\0'){
    if (isdigit(*argv) == 0){;
      return 0;
    }
    argv++;
  }
  return 1;	
}


int main(int argc, char* argv[]){
  
  //check that the total number of argument is 3 (name of program, #students, officeCapacity)
  if(argc != 3){
    printf("Usage: %s number_of_students office_capacity\n", argv[0]);
    return 1;}

  studentsDone = numberStudents = atoi(argv[1]);
  maxCapacity = officeCapacity = atoi(argv[2]);  
  

  //check that the arguments are numbers
  if (!validateArguments(argv[1]) || !validateArguments(argv[2])){
    printf("Usage: %s number_of_students office_capacity\n", argv[0]);
    return 1;}
 
  printf("The office capacity is %d.\n", officeCapacity);
  printf("The number of students is %d.\n", numberStudents);
  
  int i =  0;
  pthread_t t[numberStudents+1]; 
  pthread_mutex_init(&mutex, NULL); //initialize mutex  
  pthread_barrier_init(&barrier, NULL, 20); //initialize barrier

  pthread_create(&t[numberStudents], NULL, Professor, NULL); //start professor's thread 
 
  for (i = 0; i < numberStudents; i++){
    pthread_create(&t[i], NULL, Student, i); //start students' threads 
  } 

   for (i = 0; i < numberStudents; i++){
    pthread_join(t[i], NULL);               //finish students' threads
  } 
  
  studentsDone = 0;
  
  pthread_join(t[numberStudents], NULL); //finish professor's thread

     
  pthread_mutex_destroy(&mutex); //destroy mutex

}
