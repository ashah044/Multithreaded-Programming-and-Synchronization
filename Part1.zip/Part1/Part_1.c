#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

//PTHREAD_SYNC = 0 for no synchronization; PTHREAD_SYNC = 1 for synchronization
#define PTHREAD_SYNC 1 

int SharedVariable = 0;

//Declaration of Mutex and Barrier 
pthread_mutex_t mutex; 
pthread_barrier_t barrier; 

//Given Thread Function
void SimpleThread(int which) 
{
 int num, val;
 for(num = 0; num < 20; num++) 
  {
   if (random() > RAND_MAX / 2)
     usleep(500);
   #if PTHREAD_SYNC
//Start critical section
   pthread_mutex_lock(&mutex); 
   #endif
   val = SharedVariable;
   printf("*** thread %d sees value %d\n", which, val);
   SharedVariable = val + 1;
   #if PTHREAD_SYNC
//End critical section
   pthread_mutex_unlock(&mutex); 
   #endif
  }
 #if PTHREAD_SYNC
//Wait using barrier
 pthread_barrier_wait(&barrier);
 #endif
 val = SharedVariable;
 printf("Thread %d sees final value %d\n", which, val);
} 


int main(int argc, char* argv[])
{
  int i;
  int numOfThreads;

  //Check if no of arguments is 2
  if(argc != 2)
    {
    	printf("Error! Incorrect no of parameters\n");
    	return 1;
    }
 
  //Assign no of threads value from command line
  numOfThreads = atoi(argv[1]);

  //Check 2nd argument is a number and positive 
  for(; *argv[1] != '\0'; argv[1]++)
    {
     if (isdigit(*argv[1]) == 0 || (*argv[1]) < 0)
	{
      	    printf("Error! The parameter must be a positive number\n");
      	    return 1;
    	}
    }

  //Initialize Pthread, Mutex and Barrier
  pthread_t t[numOfThreads];
  pthread_mutex_init(&mutex, NULL);  
  pthread_barrier_init(&barrier, NULL, numOfThreads); 

  //Generate threads and join
  for (i=0; i<numOfThreads; i++)
    {
     pthread_create(&t[i], NULL, SimpleThread, i);
    } 

  for (i=0; i<numOfThreads; i++)
    {
     pthread_join(t[i],NULL);
    } 

  //Destroy mutex   
  pthread_mutex_destroy(&mutex); 

  return 0;

} 




