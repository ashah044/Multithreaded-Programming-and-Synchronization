There are two parts of this code. 

To compile the code without synchronization do the following steps:

1. Open Part_1.c
2. Replace '#define PTHREAD_SYNC 1' with '#define PTHREAD_SYNC 0'
3. Open Terminal and execute the following commands to run 5 threads-
	
	cd 'directory_for_Part_1'
	make clean
	make
	./Part_1 5

To compile the code with synchronization do the following steps:

1. Open Part_1.c
2. Replace '#define PTHREAD_SYNC 0' with '#define PTHREAD_SYNC 1'
3. Open Terminal and execute the following commands to run 5 threads-
	
	cd 'directory_for_Part_1'
	make clean
	make
	./Part_1 5

